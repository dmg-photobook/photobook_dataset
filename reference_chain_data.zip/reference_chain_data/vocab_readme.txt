Please use the Vocab.py provided in this folder when you are using the data in this .zip file. In this way, the indices of tokens would be correctly converted to actual words.
